# World Weather Repository

## Description
Daily updating global weather dataset covering temperature, humidity, wind, precipitation, and air quality for cities worldwide.

## Source
- **Origin:** Kaggle
- **Slug:** nelgiriyewithana/global-weather-repository
- **URL:** https://www.kaggle.com/datasets/nelgiriyewithana/global-weather-repository

## WDF Certification
This dataset has been verified and certified by the **World Data Foundation** under the WDF Data Integrity Standard v1.0.

- **Certified Date:** 2026-02-22
- **SHA-256 (original):** `3b0c869df02d67a2b10a5e37e24bf3922dfe894e628facde3347c33db4df3ca3`
- **Integrity Check:** Passed

## License
Please refer to the original dataset page on Kaggle for license details.

## About World Data Foundation
The World Data Foundation is an international institute dedicated to advancing global standards for data integrity, governance, and institutional trust.

Website: https://worlddatafoundation.org
